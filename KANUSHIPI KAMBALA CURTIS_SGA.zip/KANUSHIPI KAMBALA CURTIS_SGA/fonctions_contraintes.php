<?php
/**
 * fonctions_contraintes.php
 * Fonctions de vérification des contraintes métier du SGA.
 * Partie II – Q6 : Vérification des contraintes
 *
 * Un créneau est représenté par une chaîne de la forme : "Lundi_08:00-12:00"
 * Structure d'une affectation dans $planning :
 *   [
 *     'creneau'   => 'Lundi_08:00-12:00',
 *     'id_salle'  => 'AUD-L1',
 *     'id_cours'  => 'CL1-ALGO',
 *     'id_groupe' => 'L1',       // identifiant promotion ou option
 *   ]
 */

// ─────────────────────────────────────────────────────────────────────────────
// Q6.1 – salle_disponible()
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Vérifie qu'une salle n'est pas déjà occupée sur un créneau donné.
 *
 * Règle : Une salle ne peut accueillir qu'un seul groupe par créneau.
 *
 * @param  array  $planning   Tableau des affectations déjà enregistrées.
 * @param  string $id_salle   Identifiant de la salle à tester.
 * @param  string $creneau    Identifiant du créneau (ex. "Lundi_08:00-12:00").
 * @return bool               TRUE si la salle est libre, FALSE sinon.
 */
function salle_disponible($planning, $id_salle, $creneau) {
    foreach ($planning as $affectation) {
        if ($affectation['id_salle'] === $id_salle
            && $affectation['creneau'] === $creneau) {
            return false; // Salle déjà occupée
        }
    }
    return true;
}

// ─────────────────────────────────────────────────────────────────────────────
// Q6.2 – capacite_suffisante()
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Vérifie que la capacité d'une salle est suffisante pour un groupe donné.
 *
 * Règle : effectif_groupe ≤ capacite_salle
 *
 * @param  array  $salles    Tableau des salles chargées (indexé par id_salle).
 * @param  string $id_salle  Identifiant de la salle à tester.
 * @param  int    $effectif  Effectif du groupe à placer.
 * @return bool              TRUE si la capacité est suffisante, FALSE sinon.
 */
function capacite_suffisante($salles, $id_salle, $effectif) {
    if (!isset($salles[$id_salle])) {
        return false; // Salle inconnue
    }
    return $effectif <= $salles[$id_salle]['capacite'];
}

// ─────────────────────────────────────────────────────────────────────────────
// Q6.3 – creneau_libre_groupe()
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Vérifie qu'un groupe (promotion ou option) n'a pas déjà un cours sur un créneau.
 *
 * Règle : Un groupe ne peut pas être présent sur deux affectations simultanées.
 *
 * @param  array  $planning   Tableau des affectations déjà enregistrées.
 * @param  string $id_groupe  Identifiant du groupe (promo ou option).
 * @param  string $creneau    Identifiant du créneau à tester.
 * @return bool               TRUE si le groupe est libre, FALSE sinon.
 */
function creneau_libre_groupe($planning, $id_groupe, $creneau) {
    foreach ($planning as $affectation) {
        if ($affectation['id_groupe'] === $id_groupe
            && $affectation['creneau'] === $creneau) {
            return false; // Groupe déjà affecté sur ce créneau
        }
    }
    return true;
}

// ─────────────────────────────────────────────────────────────────────────────
// Fonctions de contrainte supplémentaires
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Vérifie qu'un cours n'a pas déjà été planifié (volume horaire atteint).
 * On part du principe qu'un cours de 4h = 1 créneau hebdomadaire.
 *
 * @param  array  $planning  Tableau des affectations enregistrées.
 * @param  string $id_cours  Identifiant du cours à tester.
 * @return bool              TRUE si le cours n'est pas encore planifié, FALSE sinon.
 */
function cours_non_planifie($planning, $id_cours) {
    foreach ($planning as $affectation) {
        if ($affectation['id_cours'] === $id_cours) {
            return false;
        }
    }
    return true;
}

/**
 * Recherche la première salle disponible pouvant accueillir un effectif donné
 * sur un créneau donné. Stratégie : salle la plus adaptée (capacité minimale
 * supérieure ou égale à l'effectif) pour éviter le gaspillage.
 *
 * @param  array  $salles    Tableau des salles chargées.
 * @param  array  $planning  Tableau courant du planning.
 * @param  string $creneau   Identifiant du créneau ciblé.
 * @param  int    $effectif  Effectif du groupe.
 * @return string|null       Identifiant de la salle trouvée, ou NULL si aucune.
 */
function trouver_salle_adaptee($salles, $planning, $creneau, $effectif) {
    // Trier les salles par capacité croissante pour optimiser l'allocation
    $salles_triees = $salles;
    uasort($salles_triees, function($a, $b) {
        return $a['capacite'] - $b['capacite'];
    });

    foreach ($salles_triees as $id_salle => $salle) {
        if (capacite_suffisante($salles, $id_salle, $effectif)
            && salle_disponible($planning, $id_salle, $creneau)) {
            return $id_salle;
        }
    }
    return null; // Aucune salle disponible
}

/**
 * Valide une affectation complète en vérifiant toutes les contraintes.
 *
 * @param  array  $planning   Tableau courant.
 * @param  array  $salles     Tableau des salles.
 * @param  string $id_salle   Salle proposée.
 * @param  string $id_groupe  Groupe à placer.
 * @param  string $id_cours   Cours à affecter.
 * @param  string $creneau    Créneau ciblé.
 * @param  int    $effectif   Effectif du groupe.
 * @return array              ['valide' => bool, 'erreurs' => []]
 */
function valider_affectation($planning, $salles, $id_salle, $id_groupe, $id_cours, $creneau, $effectif) {
    $erreurs = [];

    if (!salle_disponible($planning, $id_salle, $creneau)) {
        $erreurs[] = "Salle $id_salle déjà occupée sur le créneau $creneau.";
    }
    if (!capacite_suffisante($salles, $id_salle, $effectif)) {
        $cap = $salles[$id_salle]['capacite'] ?? '?';
        $erreurs[] = "Capacité insuffisante : salle $id_salle ($cap places) pour $effectif étudiants.";
    }
    if (!creneau_libre_groupe($planning, $id_groupe, $creneau)) {
        $erreurs[] = "Groupe $id_groupe déjà planifié sur le créneau $creneau.";
    }

    return [
        'valide'  => empty($erreurs),
        'erreurs' => $erreurs,
    ];
}
