<?php
/**
 * fonctions_lecture.php
 * Fonctions de lecture et chargement des fichiers de données JSON.
 * Partie II – Q5 : Lecture des fichiers de données
 */

// ─────────────────────────────────────────────────────────────────────────────
// CONSTANTES DE CHEMIN
// ─────────────────────────────────────────────────────────────────────────────
define('DATA_DIR', __DIR__ . '/data/');

// ─────────────────────────────────────────────────────────────────────────────
// FONCTION UTILITAIRE : Lecture JSON générique
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Lit un fichier JSON et retourne son contenu décodé sous forme de tableau.
 *
 * @param  string $chemin_fichier  Chemin absolu ou relatif vers le fichier JSON.
 * @return array                   Tableau associatif issu du JSON, ou tableau vide en cas d'erreur.
 */
function lire_fichier_json($chemin_fichier) {
    // Vérification de l'existence du fichier
    if (!file_exists($chemin_fichier)) {
        echo "<p class='erreur'>&#x26A0; Fichier introuvable : <strong>" . htmlspecialchars($chemin_fichier) . "</strong></p>";
        return [];
    }

    // Lecture du contenu brut
    $contenu = file_get_contents($chemin_fichier);
    if ($contenu === false) {
        echo "<p class='erreur'>&#x26A0; Impossible de lire le fichier : <strong>" . htmlspecialchars($chemin_fichier) . "</strong></p>";
        return [];
    }

    // Décodage JSON
    $donnees = json_decode($contenu, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        echo "<p class='erreur'>&#x26A0; Erreur JSON dans <strong>" . htmlspecialchars($chemin_fichier) . "</strong> : " . json_last_error_msg() . "</p>";
        return [];
    }

    return $donnees;
}

// ─────────────────────────────────────────────────────────────────────────────
// Q5.1 – charger_salles()
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Charge et valide les données des salles depuis salles.json.
 *
 * Champs requis par salle : id (string), designation (string), capacite (int > 0).
 * Retourne un tableau associatif indexé par l'identifiant de salle.
 *
 * @param  string $chemin_fichier  Chemin vers salles.json.
 * @return array                   ['AUD-L1' => ['id'=>…, 'designation'=>…, 'capacite'=>…], …]
 */
function charger_salles($chemin_fichier) {
    $raw    = lire_fichier_json($chemin_fichier);
    $salles = [];
    $champs = ['id', 'designation', 'capacite'];

    foreach ($raw as $index => $salle) {
        // Vérification des champs obligatoires
        foreach ($champs as $champ) {
            if (!isset($salle[$champ]) || $salle[$champ] === '') {
                echo "<p class='avertissement'>&#x26A0; Salle ligne " . ($index + 1) . " : champ <em>$champ</em> manquant ou vide. Ligne ignorée.</p>";
                continue 2;
            }
        }

        // Validation de la capacité
        $capacite = intval($salle['capacite']);
        if ($capacite <= 0) {
            echo "<p class='avertissement'>&#x26A0; Salle <em>{$salle['id']}</em> : capacité invalide ({$salle['capacite']}). Ligne ignorée.</p>";
            continue;
        }

        $id = trim($salle['id']);
        $salles[$id] = [
            'id'          => $id,
            'designation' => trim($salle['designation']),
            'capacite'    => $capacite,
        ];
    }

    return $salles;
}

// ─────────────────────────────────────────────────────────────────────────────
// Q5.2 – charger_promotions()
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Charge et valide les données des promotions depuis promotions.json.
 *
 * Champs requis : id (string), libelle (string), effectif (int > 0).
 * Retourne un tableau associatif indexé par l'identifiant de promotion.
 *
 * @param  string $chemin_fichier  Chemin vers promotions.json.
 * @return array                   ['L1' => ['id'=>…, 'libelle'=>…, 'effectif'=>…], …]
 */
function charger_promotions($chemin_fichier) {
    $raw        = lire_fichier_json($chemin_fichier);
    $promotions = [];
    $champs     = ['id', 'libelle', 'effectif'];

    foreach ($raw as $index => $promo) {
        foreach ($champs as $champ) {
            if (!isset($promo[$champ]) || $promo[$champ] === '') {
                echo "<p class='avertissement'>&#x26A0; Promotion ligne " . ($index + 1) . " : champ <em>$champ</em> manquant. Ligne ignorée.</p>";
                continue 2;
            }
        }

        $effectif = intval($promo['effectif']);
        if ($effectif <= 0) {
            echo "<p class='avertissement'>&#x26A0; Promotion <em>{$promo['id']}</em> : effectif invalide. Ligne ignorée.</p>";
            continue;
        }

        $id = trim($promo['id']);
        $promotions[$id] = [
            'id'      => $id,
            'libelle' => trim($promo['libelle']),
            'effectif'=> $effectif,
        ];
    }

    return $promotions;
}

// ─────────────────────────────────────────────────────────────────────────────
// Q5.3 – charger_cours()
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Charge et valide les données des cours depuis cours.json.
 *
 * Champs requis : id, intitule, volume_horaire (int > 0), type ('tronc_commun'|'option'),
 *                 promotion, option (peut être null pour tronc commun).
 * Retourne un tableau associatif indexé par l'identifiant du cours.
 *
 * @param  string $chemin_fichier  Chemin vers cours.json.
 * @return array                   ['CL1-ALGO' => […], …]
 */
function charger_cours($chemin_fichier) {
    $raw    = lire_fichier_json($chemin_fichier);
    $cours  = [];
    $champs = ['id', 'intitule', 'volume_horaire', 'type', 'promotion'];
    $types_valides = ['tronc_commun', 'option'];

    foreach ($raw as $index => $c) {
        foreach ($champs as $champ) {
            if (!isset($c[$champ]) || $c[$champ] === '') {
                echo "<p class='avertissement'>&#x26A0; Cours ligne " . ($index + 1) . " : champ <em>$champ</em> manquant. Ligne ignorée.</p>";
                continue 2;
            }
        }

        $volume = intval($c['volume_horaire']);
        if ($volume <= 0) {
            echo "<p class='avertissement'>&#x26A0; Cours <em>{$c['id']}</em> : volume horaire invalide. Ligne ignorée.</p>";
            continue;
        }

        if (!in_array($c['type'], $types_valides)) {
            echo "<p class='avertissement'>&#x26A0; Cours <em>{$c['id']}</em> : type inconnu ({$c['type']}). Ligne ignorée.</p>";
            continue;
        }

        // Un cours d'option doit avoir un identifiant d'option
        if ($c['type'] === 'option' && (empty($c['option']))) {
            echo "<p class='avertissement'>&#x26A0; Cours option <em>{$c['id']}</em> : champ 'option' manquant. Ligne ignorée.</p>";
            continue;
        }

        $id = trim($c['id']);
        $cours[$id] = [
            'id'            => $id,
            'intitule'      => trim($c['intitule']),
            'volume_horaire'=> $volume,
            'type'          => $c['type'],
            'promotion'     => trim($c['promotion']),
            'option'        => isset($c['option']) ? $c['option'] : null,
        ];
    }

    return $cours;
}

// ─────────────────────────────────────────────────────────────────────────────
// Q5.4 – charger_options()
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Charge et valide les données des groupes d'option depuis options.json.
 *
 * Champs requis : id (string), libelle (string), promotion (string), effectif (int > 0).
 * Retourne un tableau associatif indexé par l'identifiant d'option.
 *
 * @param  string $chemin_fichier  Chemin vers options.json.
 * @return array                   ['OPT-L3-SEC' => ['id'=>…, 'libelle'=>…, 'promotion'=>…, 'effectif'=>…], …]
 */
function charger_options($chemin_fichier) {
    $raw     = lire_fichier_json($chemin_fichier);
    $options = [];
    $champs  = ['id', 'libelle', 'promotion', 'effectif'];

    foreach ($raw as $index => $opt) {
        foreach ($champs as $champ) {
            if (!isset($opt[$champ]) || $opt[$champ] === '') {
                echo "<p class='avertissement'>&#x26A0; Option ligne " . ($index + 1) . " : champ <em>$champ</em> manquant. Ligne ignorée.</p>";
                continue 2;
            }
        }

        $effectif = intval($opt['effectif']);
        if ($effectif <= 0) {
            echo "<p class='avertissement'>&#x26A0; Option <em>{$opt['id']}</em> : effectif invalide. Ligne ignorée.</p>";
            continue;
        }

        $id = trim($opt['id']);
        $options[$id] = [
            'id'        => $id,
            'libelle'   => trim($opt['libelle']),
            'promotion' => trim($opt['promotion']),
            'effectif'  => $effectif,
        ];
    }

    return $options;
}

// ─────────────────────────────────────────────────────────────────────────────
// Q9 – charger_planning()
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Lit le fichier planning.json sauvegardé et retourne le tableau de planification.
 *
 * @param  string $chemin_fichier  Chemin vers planning.json.
 * @return array                   Tableau du planning, ou tableau vide si absent/invalide.
 */
function charger_planning($chemin_fichier) {
    if (!file_exists($chemin_fichier)) {
        return [];
    }
    return lire_fichier_json($chemin_fichier);
}
