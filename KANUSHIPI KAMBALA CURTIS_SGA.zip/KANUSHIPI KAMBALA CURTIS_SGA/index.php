<?php
/**
 * index.php
 * Script principal du Système de Gestion des Auditoires (SGA).
 * Partie II – Q10 (anciennement Q6 dans l'énoncé) : orchestration complète.
 *
 * Rôles :
 *  1. Chargement de tous les fichiers de données.
 *  2. Génération du planning hebdomadaire sans conflit.
 *  3. Sauvegarde du planning (JSON + TXT).
 *  4. Affichage HTML du tableau hebdomadaire.
 *  5. Rapport d'occupation + détection de conflits (bonus).
 */

// ─────────────────────────────────────────────────────────────────────────────
// INCLUSION DES MODULES
// ─────────────────────────────────────────────────────────────────────────────
require_once __DIR__ . '/fonctions_lecture.php';
require_once __DIR__ . '/fonctions_contraintes.php';
require_once __DIR__ . '/fonctions_planning.php';
require_once __DIR__ . '/fonctions_extensions.php';

// ─────────────────────────────────────────────────────────────────────────────
// TRAITEMENT : Forcer la regénération si demandé via POST
// ─────────────────────────────────────────────────────────────────────────────
$regenerer    = isset($_POST['regenerer']);
$modifier_aff = isset($_POST['modifier']) && !empty($_POST['mod_cours']);

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SGA – Système de Gestion des Auditoires</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>

<header>
    <h1> Système de Gestion des Auditoires</h1>
    <p class="subtitle">Faculté des Sciences Informatiques – Année 2025/2026</p>
    <nav>
        <a href="index.php"> Planning</a>
        <a href="formulaires.php"> Gérer les données</a>
        <a href="<?= DATA_DIR ?>planning.txt" target="_blank"> Voir TXT</a>
    </nav>
</header>

<main>

<!-- ══════════════════════════════════════════════════════════
     ÉTAPE 1 – CHARGEMENT DES FICHIERS
════════════════════════════════════════════════════════════ -->
<section>
<h2>Étape 1 — Chargement des données</h2>

<?php
$etape1_ok = true;

$salles = charger_salles(DATA_DIR . 'salles.json');
if (empty($salles)) {
    echo "<p class='erreur'> Aucune salle chargée. Vérifiez salles.json.</p>";
    $etape1_ok = false;
} else {
    echo "<p class='succes'> " . count($salles) . " salle(s) chargée(s).</p>";
}

$promotions = charger_promotions(DATA_DIR . 'promotions.json');
if (empty($promotions)) {
    echo "<p class='erreur'> Aucune promotion chargée.</p>";
    $etape1_ok = false;
} else {
    echo "<p class='succes'> " . count($promotions) . " promotion(s) chargée(s).</p>";
}

$cours = charger_cours(DATA_DIR . 'cours.json');
if (empty($cours)) {
    echo "<p class='erreur'> Aucun cours chargé.</p>";
    $etape1_ok = false;
} else {
    echo "<p class='succes'> " . count($cours) . " cours chargé(s).</p>";
}

$options = charger_options(DATA_DIR . 'options.json');
echo "<p class='succes'> " . count($options) . " groupe(s) d'option chargé(s).</p>";

$creneaux = generer_creneaux_disponibles();
echo "<p class='info'>ℹ " . count($creneaux) . " créneaux hebdomadaires disponibles (Lun–Ven, 08h–17h, blocs de 4h).</p>";
?>
</section>

<?php if (!$etape1_ok): ?>
<p class='erreur'> Chargement incomplet. Corrigez les fichiers de données avant de continuer.</p>
<?php else: ?>

<!-- ══════════════════════════════════════════════════════════
     ÉTAPE 2 – GÉNÉRATION / RECHARGEMENT DU PLANNING
════════════════════════════════════════════════════════════ -->
<section>
<h2>Étape 2 — Planning hebdomadaire</h2>

<?php
$chemin_planning = DATA_DIR . 'planning.json';
$planning        = [];
$stats           = [];
$non_planifies   = [];

// Modifier une affectation existante avant de charger/générer
if ($modifier_aff) {
    $planning_existant = charger_planning($chemin_planning);
    if (!empty($planning_existant)) {
        $res = modifier_affectation(
            $planning_existant,
            $salles,
            trim($_POST['mod_cours']),
            trim($_POST['mod_salle'] ?? ''),
            trim($_POST['mod_creneau'] ?? ''),
            $chemin_planning
        );
        echo "<p class='" . ($res['succes'] ? 'succes' : 'erreur') . "'>" . htmlspecialchars($res['message']) . "</p>";
    }
}

if ($regenerer || !file_exists($chemin_planning)) {
    // ── GÉNÉRATION ────────────────────────────────────────────────────────────
    echo "<p class='info'> Génération du planning en cours…</p>";
    $resultat    = generer_planning($salles, $promotions, $cours, $options, $creneaux);
    $planning    = $resultat['planning'];
    $stats       = $resultat['stats'];
    $non_planifies = $resultat['non_planifies'];

    // Sauvegarde
    if (sauvegarder_planning($planning, $chemin_planning)) {
        echo "<p class='succes'> Planning sauvegardé dans <em>data/planning.json</em> et <em>data/planning.txt</em>.</p>";
    } else {
        echo "<p class='erreur'> Erreur lors de la sauvegarde du planning.</p>";
    }
} else {
    // ── RECHARGEMENT ─────────────────────────────────────────────────────────
    $planning = charger_planning($chemin_planning);
    echo "<p class='info'> Planning rechargé depuis <em>data/planning.json</em> (" . count($planning) . " affectation(s)).</p>";
    $stats = [
        'total_cours'   => count($cours),
        'planifies'     => count($planning),
        'non_planifies' => 0,
        'taux_succes'   => count($cours) > 0 ? round(count($planning) / count($cours) * 100, 1) : 0,
    ];
}

// ── Statistiques ─────────────────────────────────────────────────────────────
if (!empty($stats)):
?>
<div class="stats-grid">
    <div class="stat-card"><span class="stat-val"><?= $stats['total_cours'] ?></span><span class="stat-label">Cours à planifier</span></div>
    <div class="stat-card succes"><span class="stat-val"><?= $stats['planifies'] ?></span><span class="stat-label">Cours planifiés</span></div>
    <div class="stat-card <?= $stats['non_planifies'] > 0 ? 'erreur' : 'succes' ?>"><span class="stat-val"><?= $stats['non_planifies'] ?></span><span class="stat-label">Non planifiés</span></div>
    <div class="stat-card"><span class="stat-val"><?= $stats['taux_succes'] ?>%</span><span class="stat-label">Taux de succès</span></div>
</div>
<?php endif; ?>

<?php if (!empty($non_planifies)): ?>
<h3> Cours non planifiés</h3>
<ul class="liste-erreurs">
<?php foreach ($non_planifies as $np): ?>
    <li><strong><?= htmlspecialchars($np['id_cours']) ?></strong> – <?= htmlspecialchars($np['raison']) ?></li>
<?php endforeach; ?>
</ul>
<?php endif; ?>

<!-- Bouton regénération -->
<form method="POST" style="margin: 1rem 0;">
    <button type="submit" name="regenerer" value="1" class="btn-principal" onclick="return confirm('Regénérer le planning ? L\'ancien sera écrasé.')">
         Regénérer le planning
    </button>
</form>

<?php if (!empty($planning)): ?>

<!-- ── Tableau hebdomadaire ──────────────────────────────────────────────── -->
<h3> Vue hebdomadaire</h3>
<?php afficher_planning_html($planning, $cours, $salles); ?>

<!-- ── Formulaire modification manuelle (B3) ─────────────────────────────── -->
<h3> Modifier une affectation manuellement</h3>
<form method="POST">
    <input type="hidden" name="modifier" value="1">
    <label>Cours à déplacer :
        <select name="mod_cours">
            <?php foreach ($cours as $c): ?>
            <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['id']) ?> – <?= htmlspecialchars($c['intitule']) ?></option>
            <?php endforeach; ?>
        </select>
    </label>
    <label>Nouvelle salle (laisser vide = inchangé) :
        <select name="mod_salle">
            <option value="">-- Inchangée --</option>
            <?php foreach ($salles as $s): ?>
            <option value="<?= $s['id'] ?>"><?= $s['id'] ?> (<?= $s['capacite'] ?> pl.)</option>
            <?php endforeach; ?>
        </select>
    </label>
    <label>Nouveau créneau (laisser vide = inchangé) :
        <select name="mod_creneau">
            <option value="">-- Inchangé --</option>
            <?php foreach ($creneaux as $cr): ?>
            <option value="<?= $cr ?>"><?= str_replace('_', ' ', $cr) ?></option>
            <?php endforeach; ?>
        </select>
    </label>
    <button type="submit" class="btn-secondaire"> Appliquer la modification</button>
</form>

<?php endif; ?>
</section>

<!-- ══════════════════════════════════════════════════════════
     ÉTAPE 3 – DÉTECTION DE CONFLITS (B1)
════════════════════════════════════════════════════════════ -->
<section>
<h2>Étape 3 — Détection de conflits</h2>
<?php
$conflits = detecter_conflits($planning);
afficher_conflits_html($conflits);
?>
</section>

<!-- ══════════════════════════════════════════════════════════
     ÉTAPE 4 – RAPPORT D'OCCUPATION (B2)
════════════════════════════════════════════════════════════ -->
<section>
<h2>Étape 4 — Rapport d'occupation des salles</h2>
<?php
$rapport = generer_rapport_occupation(
    $planning,
    $salles,
    $creneaux,
    DATA_DIR . 'rapport_occupation.txt'
);

echo "<p class='succes'> Rapport sauvegardé dans <em>data/rapport_occupation.txt</em></p>";
?>
<table>
    <thead>
        <tr>
            <th>Salle</th>
            <th>Désignation</th>
            <th>Capacité</th>
            <th>Créneaux occupés</th>
            <th>Créneaux libres</th>
            <th>Taux d'occupation</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($rapport as $r): ?>
    <tr>
        <td><strong><?= htmlspecialchars($r['id']) ?></strong></td>
        <td><?= htmlspecialchars($r['designation']) ?></td>
        <td><?= $r['capacite'] ?></td>
        <td><?= $r['nb_occupes'] ?></td>
        <td><?= $r['nb_libres'] ?></td>
        <td>
            <div class="barre-occupation">
                <div class="barre-fill" style="width:<?= $r['taux'] ?>%;"></div>
                <span><?= $r['taux'] ?>%</span>
            </div>
        </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
</table>
</section>

<?php endif; // fin $etape1_ok ?>

</main>
<footer>
    <p>SGA v1.0 – Faculté des Sciences Informatiques – Année académique 2025/2026</p>
    <p>Développé en PHP procédural (sans BDD, sans POO)</p>
</footer>

</body>
</html>
