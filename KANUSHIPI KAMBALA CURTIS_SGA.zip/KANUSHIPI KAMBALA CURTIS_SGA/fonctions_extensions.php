<?php
/**
 * fonctions_extensions.php
 * Extensions du SGA – Partie III (Bonus B1 à B3)
 * B1 : Détection de conflits
 * B2 : Rapport d'occupation des salles
 * B3 : Mise à jour manuelle du planning
 */

require_once __DIR__ . '/fonctions_contraintes.php';

// ─────────────────────────────────────────────────────────────────────────────
// B1 – detecter_conflits()
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Analyse un planning et détecte tous les conflits présents :
 *   - Type 1 : Même salle affectée à deux groupes sur le même créneau.
 *   - Type 2 : Même groupe planifié sur deux affectations simultanées.
 *
 * @param  array $planning  Tableau des affectations.
 * @return array            ['type1' => […], 'type2' => […]]
 */
function detecter_conflits($planning) {
    $conflits_salle  = []; // Type 1
    $conflits_groupe = []; // Type 2

    $n = count($planning);

    for ($i = 0; $i < $n; $i++) {
        for ($j = $i + 1; $j < $n; $j++) {
            $a = $planning[$i];
            $b = $planning[$j];

            // Type 1 : même salle, même créneau
            if ($a['id_salle'] === $b['id_salle']
                && $a['creneau'] === $b['creneau']) {
                $conflits_salle[] = [
                    'type'    => 'CONFLIT_SALLE',
                    'creneau' => $a['creneau'],
                    'salle'   => $a['id_salle'],
                    'cours_1' => $a['id_cours'],
                    'groupe_1'=> $a['id_groupe'],
                    'cours_2' => $b['id_cours'],
                    'groupe_2'=> $b['id_groupe'],
                ];
            }

            // Type 2 : même groupe, même créneau
            if ($a['id_groupe'] === $b['id_groupe']
                && $a['creneau'] === $b['creneau']) {
                $conflits_groupe[] = [
                    'type'    => 'CONFLIT_GROUPE',
                    'creneau' => $a['creneau'],
                    'groupe'  => $a['id_groupe'],
                    'cours_1' => $a['id_cours'],
                    'salle_1' => $a['id_salle'],
                    'cours_2' => $b['id_cours'],
                    'salle_2' => $b['id_salle'],
                ];
            }
        }
    }

    return [
        'type1'  => $conflits_salle,
        'type2'  => $conflits_groupe,
        'total'  => count($conflits_salle) + count($conflits_groupe),
    ];
}

/**
 * Affiche les conflits détectés sous forme HTML.
 *
 * @param  array $conflits  Retour de detecter_conflits().
 * @return void
 */
function afficher_conflits_html($conflits) {
    if ($conflits['total'] === 0) {
        echo "<p class='succes'>✅ Aucun conflit détecté dans le planning.</p>";
        return;
    }

    echo "<div class='conflits'>";
    echo "<h3>⚠️ {$conflits['total']} conflit(s) détecté(s)</h3>";

    if (!empty($conflits['type1'])) {
        echo "<h4>Type 1 – Conflits de salle (même salle, même créneau)</h4><ul>";
        foreach ($conflits['type1'] as $c) {
            echo "<li>Créneau <strong>{$c['creneau']}</strong> – Salle <strong>{$c['salle']}</strong> : "
                . "cours <em>{$c['cours_1']}</em> (groupe {$c['groupe_1']}) "
                . "vs cours <em>{$c['cours_2']}</em> (groupe {$c['groupe_2']})</li>";
        }
        echo "</ul>";
    }

    if (!empty($conflits['type2'])) {
        echo "<h4>Type 2 – Conflits de groupe (même groupe, même créneau)</h4><ul>";
        foreach ($conflits['type2'] as $c) {
            echo "<li>Créneau <strong>{$c['creneau']}</strong> – Groupe <strong>{$c['groupe']}</strong> : "
                . "cours <em>{$c['cours_1']}</em> en {$c['salle_1']} "
                . "vs cours <em>{$c['cours_2']}</em> en {$c['salle_2']}</li>";
        }
        echo "</ul>";
    }

    echo "</div>";
}

// ─────────────────────────────────────────────────────────────────────────────
// B2 – generer_rapport_occupation()
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Génère un rapport d'occupation des salles et le sauvegarde dans rapport_occupation.txt.
 *
 * Pour chaque salle : créneaux occupés, créneaux libres, taux d'occupation (%).
 *
 * @param  array  $planning          Tableau des affectations.
 * @param  array  $salles            Tableau des salles.
 * @param  array  $creneaux_totaux   Liste complète des créneaux disponibles.
 * @param  string $chemin_rapport    Chemin du fichier de sortie.
 * @return array                     Données du rapport indexées par salle.
 */
function generer_rapport_occupation($planning, $salles, $creneaux_totaux, $chemin_rapport) {
    $total_creneaux = count($creneaux_totaux);
    $rapport        = [];

    // Compter les créneaux occupés par salle
    $occupes = [];
    foreach ($planning as $a) {
        $occupes[$a['id_salle']][$a['creneau']] = true;
    }

    foreach ($salles as $id_salle => $salle) {
        $nb_occupes = isset($occupes[$id_salle]) ? count($occupes[$id_salle]) : 0;
        $nb_libres  = $total_creneaux - $nb_occupes;
        $taux       = $total_creneaux > 0 ? round($nb_occupes / $total_creneaux * 100, 1) : 0;

        $rapport[$id_salle] = [
            'id'           => $id_salle,
            'designation'  => $salle['designation'],
            'capacite'     => $salle['capacite'],
            'nb_occupes'   => $nb_occupes,
            'nb_libres'    => $nb_libres,
            'taux'         => $taux,
        ];
    }

    // ── Écriture du rapport TXT ───────────────────────────────────────────────
    $lignes = [];
    $lignes[] = "=== RAPPORT D'OCCUPATION DES SALLES ===";
    $lignes[] = "Généré le : " . date('d/m/Y à H:i:s');
    $lignes[] = "Créneaux totaux par salle : $total_creneaux";
    $lignes[] = str_repeat('─', 80);
    $lignes[] = sprintf("%-12s | %-35s | %8s | %8s | %8s | %6s",
                        'SALLE', 'DÉSIGNATION', 'OCCUPÉS', 'LIBRES', 'CAPACITÉ', 'TAUX');
    $lignes[] = str_repeat('─', 80);

    foreach ($rapport as $r) {
        $lignes[] = sprintf("%-12s | %-35s | %8d | %8d | %8d | %5.1f%%",
                            $r['id'],
                            substr($r['designation'], 0, 35),
                            $r['nb_occupes'],
                            $r['nb_libres'],
                            $r['capacite'],
                            $r['taux']);
    }
    $lignes[] = str_repeat('─', 80);

    file_put_contents($chemin_rapport, implode(PHP_EOL, $lignes));

    return $rapport;
}

// ─────────────────────────────────────────────────────────────────────────────
// B3 – Mise à jour manuelle du planning
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Modifie l'affectation d'un cours dans le planning en changeant sa salle ou son créneau.
 * Vérifie toutes les contraintes avant d'appliquer la modification.
 *
 * @param  array  $planning         Tableau courant des affectations (par référence).
 * @param  array  $salles           Tableau des salles.
 * @param  string $id_cours         Identifiant du cours à déplacer.
 * @param  string $nouvelle_salle   Nouvelle salle souhaitée (ou '' pour garder l'actuelle).
 * @param  string $nouveau_creneau  Nouveau créneau souhaité (ou '' pour garder l'actuel).
 * @param  string $chemin_fichier   Chemin du fichier planning.json à mettre à jour.
 * @return array  ['succes' => bool, 'message' => string, 'planning' => array]
 */
function modifier_affectation(&$planning, $salles, $id_cours, $nouvelle_salle, $nouveau_creneau, $chemin_fichier) {
    // Trouver l'index de l'affectation actuelle
    $index = null;
    foreach ($planning as $i => $a) {
        if ($a['id_cours'] === $id_cours) {
            $index = $i;
            break;
        }
    }

    if ($index === null) {
        return ['succes' => false, 'message' => "Cours '$id_cours' introuvable dans le planning.", 'planning' => $planning];
    }

    $ancienne = $planning[$index];
    $salle_cible   = !empty($nouvelle_salle)  ? $nouvelle_salle  : $ancienne['id_salle'];
    $creneau_cible = !empty($nouveau_creneau) ? $nouveau_creneau : $ancienne['creneau'];

    // Construire un planning temporaire sans l'affectation actuelle
    $planning_temp = array_values(array_filter($planning, function($a, $i) use ($index) {
        return $i !== $index;
    }, ARRAY_FILTER_USE_BOTH));

    // Vérification des contraintes sur le planning sans cette affectation
    $validation = valider_affectation(
        $planning_temp,
        $salles,
        $salle_cible,
        $ancienne['id_groupe'],
        $id_cours,
        $creneau_cible,
        $ancienne['effectif']
    );

    if (!$validation['valide']) {
        return [
            'succes'  => false,
            'message' => "Modification refusée : " . implode(' | ', $validation['erreurs']),
            'planning'=> $planning,
        ];
    }

    // Appliquer la modification
    $planning[$index]['id_salle'] = $salle_cible;
    $planning[$index]['creneau']  = $creneau_cible;

    // Réécrire le fichier JSON
    require_once __DIR__ . '/fonctions_planning.php';
    sauvegarder_planning($planning, $chemin_fichier);

    return [
        'succes'  => true,
        'message' => "Cours '$id_cours' déplacé vers salle '$salle_cible', créneau '$creneau_cible'.",
        'planning'=> $planning,
    ];
}
