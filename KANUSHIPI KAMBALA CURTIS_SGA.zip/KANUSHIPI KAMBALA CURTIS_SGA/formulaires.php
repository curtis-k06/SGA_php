<?php
/**
 * formulaires.php
 * Bonus B4 – Formulaires HTML/PHP de saisie et modification des données.
 * Permet à l'apparitorat de gérer salles, promotions et cours via le navigateur.
 */

require_once __DIR__ . '/fonctions_lecture.php';

$message = '';
$type_message = '';

// ─────────────────────────────────────────────────────────────────────────────
// Traitement des soumissions de formulaires
// ─────────────────────────────────────────────────────────────────────────────

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = isset($_POST['action']) ? $_POST['action'] : '';

    // ── Ajout / modification d'une salle ─────────────────────────────────────
    if ($action === 'sauver_salle') {
        $id       = trim($_POST['id'] ?? '');
        $desig    = trim($_POST['designation'] ?? '');
        $capacite = intval($_POST['capacite'] ?? 0);

        if ($id === '' || $desig === '' || $capacite <= 0) {
            $message = "Tous les champs sont requis et la capacité doit être > 0.";
            $type_message = 'erreur';
        } else {
            $salles = charger_salles(DATA_DIR . 'salles.json');
            $salles[$id] = ['id' => $id, 'designation' => $desig, 'capacite' => $capacite];
            // Re-sérialiser en tableau indexé
            $data = array_values($salles);
            file_put_contents(DATA_DIR . 'salles.json', json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            $message = "Salle '$id' enregistrée avec succès.";
            $type_message = 'succes';
        }
    }

    // ── Suppression d'une salle ───────────────────────────────────────────────
    if ($action === 'supprimer_salle') {
        $id = trim($_POST['id_suppr'] ?? '');
        if ($id !== '') {
            $salles = charger_salles(DATA_DIR . 'salles.json');
            if (isset($salles[$id])) {
                unset($salles[$id]);
                file_put_contents(DATA_DIR . 'salles.json', json_encode(array_values($salles), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                $message = "Salle '$id' supprimée.";
                $type_message = 'succes';
            } else {
                $message = "Salle '$id' introuvable.";
                $type_message = 'erreur';
            }
        }
    }

    // ── Ajout / modification d'une promotion ─────────────────────────────────
    if ($action === 'sauver_promotion') {
        $id      = trim($_POST['promo_id'] ?? '');
        $libelle = trim($_POST['promo_libelle'] ?? '');
        $effectif= intval($_POST['promo_effectif'] ?? 0);

        if ($id === '' || $libelle === '' || $effectif <= 0) {
            $message = "Tous les champs promotion sont requis.";
            $type_message = 'erreur';
        } else {
            $promos = charger_promotions(DATA_DIR . 'promotions.json');
            $promos[$id] = ['id' => $id, 'libelle' => $libelle, 'effectif' => $effectif];
            file_put_contents(DATA_DIR . 'promotions.json', json_encode(array_values($promos), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            $message = "Promotion '$id' enregistrée.";
            $type_message = 'succes';
        }
    }

    // ── Ajout d'un cours ─────────────────────────────────────────────────────
    if ($action === 'sauver_cours') {
        $id      = trim($_POST['cours_id'] ?? '');
        $intitule= trim($_POST['cours_intitule'] ?? '');
        $volume  = intval($_POST['cours_volume'] ?? 0);
        $type    = $_POST['cours_type'] ?? '';
        $promo   = trim($_POST['cours_promo'] ?? '');
        $option  = trim($_POST['cours_option'] ?? '');

        if ($id === '' || $intitule === '' || $volume <= 0 || $promo === '') {
            $message = "Tous les champs cours sont requis.";
            $type_message = 'erreur';
        } else {
            $cours_data = charger_cours(DATA_DIR . 'cours.json');
            $cours_data[$id] = [
                'id'             => $id,
                'intitule'       => $intitule,
                'volume_horaire' => $volume,
                'type'           => $type,
                'promotion'      => $promo,
                'option'         => $option !== '' ? $option : null,
            ];
            file_put_contents(DATA_DIR . 'cours.json', json_encode(array_values($cours_data), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            $message = "Cours '$id' enregistré.";
            $type_message = 'succes';
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Chargement des données actuelles
// ─────────────────────────────────────────────────────────────────────────────
$salles     = charger_salles(DATA_DIR . 'salles.json');
$promotions = charger_promotions(DATA_DIR . 'promotions.json');
$cours      = charger_cours(DATA_DIR . 'cours.json');
$options    = charger_options(DATA_DIR . 'options.json');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>SGA – Gestion des données</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header><h1>⚙️ SGA – Administration des données</h1>
<nav><a href="index.php">📅 Planning</a> | <a href="formulaires.php">⚙️ Données</a></nav>
</header>
<main>

<?php if ($message): ?>
    <p class="<?= $type_message ?>"><?= htmlspecialchars($message) ?></p>
<?php endif; ?>

<!-- ═══════════════════════════════════════════════════════
     SECTION SALLES
══════════════════════════════════════════════════════════ -->
<section>
<h2>🏛️ Gestion des Salles</h2>

<h3>Ajouter / Modifier une salle</h3>
<form method="POST">
    <input type="hidden" name="action" value="sauver_salle">
    <label>Identifiant (ex. AUD-L1) :
        <input type="text" name="id" required placeholder="AUD-L1">
    </label>
    <label>Désignation :
        <input type="text" name="designation" required placeholder="Auditoire principal">
    </label>
    <label>Capacité :
        <input type="number" name="capacite" min="1" required placeholder="200">
    </label>
    <button type="submit">💾 Enregistrer</button>
</form>

<h3>Salles enregistrées</h3>
<table>
    <thead><tr><th>ID</th><th>Désignation</th><th>Capacité</th><th>Action</th></tr></thead>
    <tbody>
    <?php foreach ($salles as $s): ?>
    <tr>
        <td><?= htmlspecialchars($s['id']) ?></td>
        <td><?= htmlspecialchars($s['designation']) ?></td>
        <td><?= $s['capacite'] ?></td>
        <td>
            <form method="POST" style="display:inline;">
                <input type="hidden" name="action" value="supprimer_salle">
                <input type="hidden" name="id_suppr" value="<?= htmlspecialchars($s['id']) ?>">
                <button type="submit" class="btn-danger" onclick="return confirm('Supprimer cette salle ?')">🗑️</button>
            </form>
        </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
</table>
</section>

<!-- ═══════════════════════════════════════════════════════
     SECTION PROMOTIONS
══════════════════════════════════════════════════════════ -->
<section>
<h2>🎓 Gestion des Promotions</h2>

<h3>Ajouter / Modifier une promotion</h3>
<form method="POST">
    <input type="hidden" name="action" value="sauver_promotion">
    <label>ID Promotion :
        <input type="text" name="promo_id" required placeholder="L1">
    </label>
    <label>Libellé :
        <input type="text" name="promo_libelle" required placeholder="Licence 1">
    </label>
    <label>Effectif :
        <input type="number" name="promo_effectif" min="1" required placeholder="200">
    </label>
    <button type="submit">💾 Enregistrer</button>
</form>

<h3>Promotions enregistrées</h3>
<table>
    <thead><tr><th>ID</th><th>Libellé</th><th>Effectif</th></tr></thead>
    <tbody>
    <?php foreach ($promotions as $p): ?>
    <tr>
        <td><?= htmlspecialchars($p['id']) ?></td>
        <td><?= htmlspecialchars($p['libelle']) ?></td>
        <td><?= $p['effectif'] ?></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
</table>
</section>

<!-- ═══════════════════════════════════════════════════════
     SECTION COURS
══════════════════════════════════════════════════════════ -->
<section>
<h2>📚 Gestion des Cours</h2>

<h3>Ajouter un cours</h3>
<form method="POST">
    <input type="hidden" name="action" value="sauver_cours">
    <label>ID Cours : <input type="text" name="cours_id" required placeholder="CL1-ALGO"></label>
    <label>Intitulé : <input type="text" name="cours_intitule" required></label>
    <label>Volume horaire (h) : <input type="number" name="cours_volume" min="1" value="4" required></label>
    <label>Type :
        <select name="cours_type">
            <option value="tronc_commun">Tronc commun</option>
            <option value="option">Option</option>
        </select>
    </label>
    <label>Promotion :
        <select name="cours_promo">
            <?php foreach ($promotions as $p): ?>
            <option value="<?= $p['id'] ?>"><?= $p['id'] ?> – <?= htmlspecialchars($p['libelle']) ?></option>
            <?php endforeach; ?>
        </select>
    </label>
    <label>Option (si cours d'option) :
        <select name="cours_option">
            <option value="">-- Aucune --</option>
            <?php foreach ($options as $o): ?>
            <option value="<?= $o['id'] ?>"><?= $o['id'] ?> – <?= htmlspecialchars($o['libelle']) ?></option>
            <?php endforeach; ?>
        </select>
    </label>
    <button type="submit">💾 Enregistrer</button>
</form>

<h3>Cours enregistrés (<?= count($cours) ?>)</h3>
<table>
    <thead><tr><th>ID</th><th>Intitulé</th><th>Type</th><th>Promo</th><th>Vol. h.</th></tr></thead>
    <tbody>
    <?php foreach ($cours as $c): ?>
    <tr>
        <td><?= htmlspecialchars($c['id']) ?></td>
        <td><?= htmlspecialchars($c['intitule']) ?></td>
        <td><span class="badge <?= $c['type'] === 'option' ? 'badge-option' : 'badge-tc' ?>"><?= $c['type'] ?></span></td>
        <td><?= htmlspecialchars($c['promotion']) ?></td>
        <td><?= $c['volume_horaire'] ?>h</td>
    </tr>
    <?php endforeach; ?>
    </tbody>
</table>
</section>

</main>
<footer><p>SGA – Faculté des Sciences Informatiques – 2025/2026</p></footer>
</body>
</html>
