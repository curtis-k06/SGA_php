<?php
/**
 * fonctions_planning.php
 * Fonctions de génération, sauvegarde et affichage du planning hebdomadaire.
 * Partie II – Q7 (génération), Q8 (sauvegarde), Q9 (affichage HTML)
 */

require_once __DIR__ . '/fonctions_contraintes.php';

// ─────────────────────────────────────────────────────────────────────────────
// CRENEAUX DE RÉFÉRENCE
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Génère la liste des créneaux hebdomadaires disponibles.
 * Semaine du lundi au vendredi, créneaux de 4 h : 08:00-12:00 et 13:00-17:00.
 *
 * @return array  Liste de chaînes "Jour_HH:MM-HH:MM"
 */
function generer_creneaux_disponibles() {
    $jours    = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi'];
    $tranches = ['08:00-12:00', '13:00-17:00'];
    $creneaux = [];

    foreach ($jours as $jour) {
        foreach ($tranches as $tranche) {
            $creneaux[] = $jour . '_' . $tranche;
        }
    }
    return $creneaux; // 10 créneaux au total
}

// ─────────────────────────────────────────────────────────────────────────────
// Q7 – generer_planning()
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Génère un planning hebdomadaire sans conflit à partir des données chargées.
 *
 * STRATÉGIE D'AFFECTATION :
 *  1. On itère sur chaque cours à planifier.
 *  2. On détermine l'effectif du groupe concerné (promotion entière ou sous-groupe option).
 *  3. Pour chaque créneau disponible (ordre chronologique), on vérifie :
 *       a) Le groupe n'est pas déjà affecté sur ce créneau.
 *       b) Il existe une salle libre avec une capacité suffisante.
 *  4. On choisit la salle dont la capacité est la plus proche de l'effectif
 *     (tri croissant) pour éviter de monopoliser les grandes salles.
 *  5. Dès qu'un créneau valide est trouvé, on enregistre l'affectation et on passe
 *     au cours suivant.
 *  6. Les cours ne pouvant être placés (toutes salles/créneaux saturés) sont consignés
 *     dans un tableau $non_planifies retourné avec le planning.
 *
 * @param  array  $salles               Tableau des salles (issu de charger_salles).
 * @param  array  $promotions           Tableau des promotions.
 * @param  array  $cours                Tableau des cours.
 * @param  array  $options              Tableau des groupes d'option.
 * @param  array  $creneaux_disponibles Liste des créneaux (issu de generer_creneaux_disponibles).
 * @return array  ['planning' => […], 'non_planifies' => […], 'stats' => […]]
 */
function generer_planning($salles, $promotions, $cours, $options, $creneaux_disponibles) {
    $planning       = [];
    $non_planifies  = [];

    foreach ($cours as $id_cours => $c) {

        // ── Détermination du groupe et de l'effectif ──────────────────────────
        if ($c['type'] === 'tronc_commun') {
            $id_groupe = $c['promotion'];
            $effectif  = isset($promotions[$id_groupe]) ? $promotions[$id_groupe]['effectif'] : 0;
        } else {
            // Cours d'option : le groupe est l'option elle-même
            $id_groupe = $c['option'];
            $effectif  = isset($options[$id_groupe]) ? $options[$id_groupe]['effectif'] : 0;
        }

        if ($effectif <= 0) {
            $non_planifies[] = [
                'id_cours' => $id_cours,
                'raison'   => "Effectif nul ou groupe '$id_groupe' introuvable.",
            ];
            continue;
        }

        // ── Recherche d'un créneau + salle valides ─────────────────────────────
        $affecte = false;

        foreach ($creneaux_disponibles as $creneau) {

            // Contrainte 1 : groupe libre sur ce créneau
            if (!creneau_libre_groupe($planning, $id_groupe, $creneau)) {
                continue;
            }

            // Contrainte 2 : trouver une salle avec capacité suffisante et libre
            $id_salle = trouver_salle_adaptee($salles, $planning, $creneau, $effectif);

            if ($id_salle !== null) {
                // Affectation valide → on l'enregistre
                $planning[] = [
                    'creneau'   => $creneau,
                    'id_salle'  => $id_salle,
                    'id_cours'  => $id_cours,
                    'id_groupe' => $id_groupe,
                    'effectif'  => $effectif,
                ];
                $affecte = true;
                break; // Passe au cours suivant
            }
        }

        if (!$affecte) {
            $non_planifies[] = [
                'id_cours' => $id_cours,
                'raison'   => "Aucun créneau / salle disponible pour l'effectif de $effectif étudiants.",
            ];
        }
    }

    // ── Statistiques sommaires ─────────────────────────────────────────────
    $stats = [
        'total_cours'      => count($cours),
        'planifies'        => count($planning),
        'non_planifies'    => count($non_planifies),
        'taux_succes'      => count($cours) > 0
                             ? round(count($planning) / count($cours) * 100, 1)
                             : 0,
    ];

    return [
        'planning'      => $planning,
        'non_planifies' => $non_planifies,
        'stats'         => $stats,
    ];
}

// ─────────────────────────────────────────────────────────────────────────────
// Q8 – sauvegarder_planning()
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Sauvegarde le planning dans deux formats :
 *  – planning.json : structure JSON complète (rechargeable).
 *  – planning.txt  : format lisible ligne par ligne.
 *
 * Format TXT : JOUR | DEBUT | FIN | SALLE | COURS | GROUPE | EFFECTIF
 *
 * @param  array  $planning         Tableau des affectations.
 * @param  string $chemin_fichier   Chemin de base (sans extension) ou chemin .json complet.
 * @return bool                     TRUE si l'écriture a réussi, FALSE sinon.
 */
function sauvegarder_planning($planning, $chemin_fichier) {
    // ── Sauvegarde JSON ───────────────────────────────────────────────────────
    $json = json_encode($planning, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        echo "<p class='erreur'>Erreur lors de l'encodage JSON du planning.</p>";
        return false;
    }

    $chemin_json = preg_replace('/\.(json|txt)$/', '', $chemin_fichier) . '.json';
    if (file_put_contents($chemin_json, $json) === false) {
        echo "<p class='erreur'>Impossible d'écrire le fichier : " . htmlspecialchars($chemin_json) . "</p>";
        return false;
    }

    // ── Sauvegarde TXT lisible ────────────────────────────────────────────────
    $chemin_txt = preg_replace('/\.(json|txt)$/', '', $chemin_fichier) . '.txt';
    $lignes = [];
    $lignes[] = str_repeat('-', 85);
    $lignes[] = sprintf("%-12s | %-5s | %-5s | %-12s | %-15s | %-14s | %s",
                        'JOUR', 'DEBUT', 'FIN', 'SALLE', 'COURS', 'GROUPE', 'EFFECTIF');
    $lignes[] = str_repeat('-', 85);

    foreach ($planning as $a) {
        // Décomposer "Lundi_08:00-12:00" → jour + debut + fin
        list($jour, $tranche) = explode('_', $a['creneau']);
        list($debut, $fin)    = explode('-', $tranche);

        $lignes[] = sprintf("%-12s | %-5s | %-5s | %-12s | %-15s | %-14s | %d",
                            $jour,
                            $debut,
                            $fin,
                            $a['id_salle'],
                            $a['id_cours'],
                            $a['id_groupe'],
                            $a['effectif']);
    }
    $lignes[] = str_repeat('-', 85);
    $lignes[] = "Généré le : " . date('d/m/Y à H:i:s');

    if (file_put_contents($chemin_txt, implode(PHP_EOL, $lignes)) === false) {
        echo "<p class='erreur'>Impossible d'écrire le fichier TXT.</p>";
        return false;
    }

    return true;
}

// ─────────────────────────────────────────────────────────────────────────────
// Q9 – afficher_planning_html()
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Affiche le planning sous forme de tableau HTML hebdomadaire.
 * Colonnes = jours (Lundi→Vendredi), Lignes = créneaux horaires.
 * Chaque cellule indique : salle / cours / groupe.
 *
 * @param  array $planning  Tableau des affectations (chargé depuis JSON ou généré).
 * @param  array $cours     Tableau des cours (pour récupérer les intitulés).
 * @param  array $salles    Tableau des salles.
 * @return void             Produit directement du HTML.
 */
function afficher_planning_html($planning, $cours = [], $salles = []) {
    $jours    = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi'];
    $tranches = ['08:00-12:00', '13:00-17:00'];

    // Indexer le planning : $grille[jour][tranche] = [ affectation, … ]
    $grille = [];
    foreach ($jours as $j) {
        foreach ($tranches as $t) {
            $grille[$j][$t] = [];
        }
    }

    foreach ($planning as $a) {
        list($jour, $tranche) = explode('_', $a['creneau']);
        if (isset($grille[$jour][$tranche])) {
            $grille[$jour][$tranche][] = $a;
        }
    }

    // ── Rendu HTML ────────────────────────────────────────────────────────────
    echo '<div class="planning-wrapper">';
    echo '<table class="planning-table">';

    // En-tête
    echo '<thead><tr><th>Créneau</th>';
    foreach ($jours as $j) {
        echo "<th>$j</th>";
    }
    echo '</tr></thead><tbody>';

    foreach ($tranches as $tranche) {
        list($debut, $fin) = explode('-', $tranche);
        echo "<tr>";
        echo "<td class='creneau-label'><strong>$debut</strong><br>↓<br><strong>$fin</strong></td>";

        foreach ($jours as $jour) {
            $affectations = $grille[$jour][$tranche];
            echo "<td class='cell-planning " . (empty($affectations) ? 'cell-libre' : 'cell-occupe') . "'>";

            if (empty($affectations)) {
                echo "<span class='libre'>Libre</span>";
            } else {
                foreach ($affectations as $a) {
                    $intitule = isset($cours[$a['id_cours']]) ? $cours[$a['id_cours']]['intitule'] : $a['id_cours'];
                    $desig    = isset($salles[$a['id_salle']]) ? $salles[$a['id_salle']]['designation'] : $a['id_salle'];
                    echo "<div class='bloc-cours'>";
                    echo "<span class='cours-nom'>" . htmlspecialchars($intitule) . "</span>";
                    echo "<span class='cours-salle'>📍 " . htmlspecialchars($a['id_salle']) . "</span>";
                    echo "<span class='cours-groupe'>👥 " . htmlspecialchars($a['id_groupe']) . " ({$a['effectif']} ét.)</span>";
                    echo "</div>";
                }
            }
            echo "</td>";
        }
        echo "</tr>";
    }

    echo '</tbody></table></div>';
}
